# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, date

class GmailDashboard(models.TransientModel):
    _name = 'gmail.dashboard'
    _description = 'Gmail Dashboard'

    # Computed fields for dashboard statistics
    total_messages = fields.Integer(
        string='Total Messages',
        compute='_compute_statistics',
        help='Total number of messages'
    )
    
    unread_messages = fields.Integer(
        string='Unread Messages',
        compute='_compute_statistics',
        help='Number of unread messages'
    )
    
    sent_today = fields.Integer(
        string='Sent Today',
        compute='_compute_statistics',
        help='Messages sent today'
    )
    
    total_accounts = fields.Integer(
        string='Total Accounts',
        compute='_compute_statistics',
        help='Number of Gmail accounts'
    )
    
    latest_messages = fields.Many2many(
        'gmail.message',
        compute='_compute_latest_messages',
        string='Latest Messages',
        help='Latest inbox messages'
    )

    @api.depends()
    def _compute_statistics(self):
        """Compute dashboard statistics"""
        for record in self:
            try:
                # Get Gmail message model
                message_model = self.env['gmail.message']
                account_model = self.env['gmail.account']
                
                # Calculate statistics
                record.total_messages = message_model.search_count([])
                record.unread_messages = message_model.search_count([('is_read', '=', False)])
                record.total_accounts = account_model.search_count([])
                
                # Calculate today's sent messages
                today_start = datetime.combine(date.today(), datetime.min.time())
                today_end = datetime.combine(date.today(), datetime.max.time())
                
                record.sent_today = message_model.search_count([
                    ('direction', '=', 'outbound'),
                    ('date', '>=', today_start),
                    ('date', '<=', today_end)
                ])
            except Exception as e:
                # Set default values if models don't exist yet
                record.total_messages = 0
                record.unread_messages = 0
                record.total_accounts = 0
                record.sent_today = 0

    @api.depends()
    def _compute_latest_messages(self):
        """Get latest inbox messages for dashboard"""
        for record in self:
            try:
                # Get latest 20 inbox messages
                latest = self.env['gmail.message'].search([
                    ('direction', '=', 'inbound')
                ], limit=20, order='date desc')
                
                # Assign the recordset directly
                record.latest_messages = latest
            except Exception as e:
                # Set empty recordset if model doesn't exist
                record.latest_messages = self.env['gmail.message']

    def action_view_inbox(self):
        """Open inbox view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Inbox',
            'res_model': 'gmail.message',
            'view_mode': 'tree,form',
            'domain': [('direction', '=', 'inbound')],
            'context': {'search_default_unread': 1},
        }

    def action_view_sent(self):
        """Open sent messages view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Sent Messages',
            'res_model': 'gmail.message',
            'view_mode': 'tree,form',
            'domain': [('direction', '=', 'outbound')],
        }

    def action_view_drafts(self):
        """Open drafts view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Drafts',
            'res_model': 'gmail.message',
            'view_mode': 'tree,form',
            'domain': [('direction', '=', 'draft')],
        }

    def action_view_all_messages(self):
        """Open all messages view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'All Messages',
            'res_model': 'gmail.message',
            'view_mode': 'tree,form',
        }

    def action_view_accounts(self):
        """Open Gmail accounts view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Gmail Accounts',
            'res_model': 'gmail.account',
            'view_mode': 'tree,form',
        }

    def action_send_new_mail(self):
        """Open compose mail wizard"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Compose Email',
            'res_model': 'gmail.send.mail',
            'view_mode': 'form',
            'target': 'new',
        }
