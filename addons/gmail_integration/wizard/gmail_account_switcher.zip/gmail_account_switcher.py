# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import json
import logging

_logger = logging.getLogger(__name__)


class GmailAccountSwitcher(models.TransientModel):
    _name = 'gmail.account.switcher'
    _description = 'Gmail Account Switcher'

    # Current Account Information
    current_account_id = fields.Many2one(
        'gmail.account',
        string='Current Account',
        readonly=True,
        help='Currently active Gmail account'
    )
    
    current_account_name = fields.Char(
        string='Current Account Name',
        compute='_compute_current_account_info',
        readonly=True
    )
    
    current_account_email = fields.Char(
        string='Current Account Email',
        compute='_compute_current_account_info',
        readonly=True
    )
    
    current_account_avatar = fields.Binary(
        string='Current Account Avatar',
        compute='_compute_current_account_info',
        readonly=True
    )
    
    # Selection Fields
    selected_account_id = fields.Many2one(
        'gmail.account',
        string='Selected Account',
        help='Account selected for switching'
    )
    
    available_account_ids = fields.Many2many(
        'gmail.account',
        string='Available Accounts',
        compute='_compute_available_accounts',
        help='Gmail accounts accessible by current user'
    )
    
    # Account Lines for Display (Card Style)
    available_account_lines = fields.One2many(
        'gmail.account.switcher.lines',
        'switcher_id',
        string='Available Accounts',
        compute='_compute_account_lines'
    )

    @api.depends('current_account_id')
    def _compute_current_account_info(self):
        """Compute current account display information"""
        for record in self:
            if record.current_account_id:
                account = record.current_account_id
                record.current_account_name = account.name or account.email_address.split('@')[0].title()
                record.current_account_email = account.email_address
                # Generate avatar
                record.current_account_avatar = self._generate_avatar(account.email_address)
            else:
                record.current_account_name = ''
                record.current_account_email = ''
                record.current_account_avatar = False

    @api.depends()
    def _compute_available_accounts(self):
        """Get all logged-in Gmail accounts (excluding current account) - SIMPLIFIED"""
        for record in self:
            # SIMPLE APPROACH - Get ALL connected accounts
            all_connected = self.env['gmail.account'].search([
                ('status', '=', 'connected')
            ])
            
            _logger.info(f"Gmail Switcher: Found {len(all_connected)} connected accounts")
            for acc in all_connected:
                _logger.info(f"  - {acc.email_address} (ID: {acc.id}, User: {acc.user_id.name if acc.user_id else 'No User'})")
            
            # Filter by current user's accounts only
            user_accounts = all_connected.filtered(lambda a: a.user_id.id == self.env.user.id)
            _logger.info(f"Gmail Switcher: User {self.env.user.name} has {len(user_accounts)} accounts")
            
            # Remove current account
            if record.current_account_id:
                available = user_accounts.filtered(lambda a: a.id != record.current_account_id.id)
                _logger.info(f"Gmail Switcher: Current account is {record.current_account_id.email_address}")
                _logger.info(f"Gmail Switcher: Available accounts after removing current: {len(available)}")
            else:
                available = user_accounts
                _logger.info(f"Gmail Switcher: No current account set, showing all {len(available)} user accounts")
            
            for acc in available:
                _logger.info(f"Gmail Switcher: Available account: {acc.email_address}")
            
            record.available_account_ids = available

    @api.depends('available_account_ids')
    def _compute_account_lines(self):
        """Create account lines for card display"""
        for record in self:
            # Clear existing lines
            record.available_account_lines = [(5, 0, 0)]
            
            lines_data = []
            for account in record.available_account_ids:
                lines_data.append((0, 0, {
                    'account_id': account.id,
                    'account_name': account.name or account.email_address.split('@')[0].title(),
                    'account_email': account.email_address,
                    'account_status': account.status,
                    'account_avatar': self._generate_avatar(account.email_address),
                    'unread_count': getattr(account, 'unread_messages', 0) or 0,
                }))
            
            record.available_account_lines = lines_data

    def _generate_avatar(self, email):
        """Generate avatar from email"""
        try:
            # Create circular avatar with initial
            initial = email[0].upper() if email else 'G'
            
            # Generate color based on email hash
            import hashlib
            hash_object = hashlib.md5(email.encode())
            hex_dig = hash_object.hexdigest()
            
            # Convert to color
            color_int = int(hex_dig[:6], 16)
            colors = [
                '#1a73e8', '#34a853', '#ea4335', '#fbbc04', 
                '#9aa0a6', '#4285f4', '#0f9d58', '#f4b400'
            ]
            color = colors[color_int % len(colors)]
            
            # Create SVG avatar
            svg_avatar = f'''
            <svg width="50" height="50" xmlns="http://www.w3.org/2000/svg">
                <circle cx="25" cy="25" r="25" fill="{color}"/>
                <text x="25" y="32" font-family="Arial, sans-serif" font-size="18" 
                      fill="white" text-anchor="middle" font-weight="500">{initial}</text>
            </svg>
            '''
            
            # Convert SVG to base64
            return base64.b64encode(svg_avatar.encode()).decode()
            
        except Exception as e:
            _logger.warning(f"Avatar generation failed: {e}")
            return False

    @api.model
    def default_get(self, fields_list):
        """Set default values"""
        res = super().default_get(fields_list)
        
        # Try to get current account from session first
        current_account_id = None
        try:
            from odoo.http import request
            if request and hasattr(request, 'session'):
                current_account_id = request.session.get('gmail_active_account_id')
                if current_account_id:
                    _logger.info(f"Gmail Switcher: Got current account from session: {current_account_id}")
        except:
            pass
        
        # If no session account, use the first connected account
        if not current_account_id:
            first_account = self.env['gmail.account'].search([
                ('user_id', '=', self.env.user.id),
                ('status', '=', 'connected')
            ], limit=1)
            if first_account:
                current_account_id = first_account.id
                _logger.info(f"Gmail Switcher: Using first connected account as current: {first_account.email_address}")
        
        if current_account_id:
            res['current_account_id'] = current_account_id
            
        return res

    def action_select_account(self):
        """Select this account for switching from kanban view"""
        self.ensure_one()
        account_id = self._context.get('account_id')
        return self.action_switch_account(account_id)

    def action_switch_account(self, account_id=None):
        """Switch to selected account"""
        if not account_id:
            # Get from context
            account_id = self._context.get('account_id')
        
        if not account_id:
            raise UserError(_('Please select an account to switch to.'))
        
        account = self.env['gmail.account'].browse(account_id)
        if not account.exists():
            raise UserError(_('Selected account not found.'))
        
        # Verify access rights and status
        if account.status != 'connected':
            raise UserError(_('Selected account is not connected.'))
        
        # Set active account in session
        try:
            from odoo.http import request
            if request and hasattr(request, 'session'):
                request.session['gmail_active_account_id'] = account.id
                _logger.info(f"Switched to Gmail account: {account.email_address}")
        except Exception as e:
            _logger.warning(f"Failed to set session account: {e}")
        
        # Return close action and refresh
        return {
            'type': 'ir.actions.act_window_close'
        }

    def action_add_account(self):
        """Open Gmail account creation form"""
        self.ensure_one()
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Add Gmail Account'),
            'res_model': 'gmail.account',
            'view_mode': 'form',
            'target': 'current',
            'context': {
                'default_user_id': self.env.user.id,
            }
        }

    def action_sign_out_current(self):
        """Sign out from current account"""
        return self.action_sign_out_account(self.current_account_id.id)

    def action_sign_out_account(self, account_id=None):
        """Sign out from specific account"""
        if not account_id:
            account_id = self._context.get('account_id')
        
        if not account_id:
            raise UserError(_('No account specified for sign out.'))
        
        account = self.env['gmail.account'].browse(account_id)
        if not account.exists():
            raise UserError(_('Account not found.'))
        
        try:
            # Call the disconnect method on the account
            if hasattr(account, 'action_disconnect_gmail'):
                account.action_disconnect_gmail()
            elif hasattr(account, 'action_disconnect'):
                account.action_disconnect()
            else:
                # Fallback - set status to draft
                account.status = 'draft'
            
            # Clear session if it was the active account
            try:
                from odoo.http import request
                if request and hasattr(request, 'session'):
                    active_account_id = request.session.get('gmail_active_account_id')
                    if active_account_id == account_id:
                        request.session.pop('gmail_active_account_id', None)
            except:
                pass
            
            # Return success notification and close
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Signed Out'),
                    'message': _('Successfully signed out from %s') % account.email_address,
                    'type': 'success',
                }
            }
            
        except Exception as e:
            _logger.error(f"Sign out failed: {e}")
            raise UserError(_('Failed to sign out: %s') % str(e))

    def debug_accounts_info(self):
        """Debug method to check what's happening"""
        self.ensure_one()
        
        _logger.info("=== GMAIL SWITCHER DEBUG START ===")
        
        # Check all accounts
        all_accounts = self.env['gmail.account'].search([])
        _logger.info(f"Total accounts in system: {len(all_accounts)}")
        
        for acc in all_accounts:
            _logger.info(f"Account {acc.email_address}: Status={acc.status}, User={acc.user_id.name if acc.user_id else 'None'}")
        
        # Check connected accounts
        connected = self.env['gmail.account'].search([('status', '=', 'connected')])
        _logger.info(f"Connected accounts: {len(connected)}")
        
        # Check current user
        _logger.info(f"Current user: {self.env.user.name} (ID: {self.env.user.id})")
        
        # Force recompute
        self._compute_available_accounts()
        _logger.info(f"Available accounts after recompute: {len(self.available_account_ids)}")
        
        _logger.info("=== GMAIL SWITCHER DEBUG END ===")
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Debug Complete',
                'message': f'Found {len(self.available_account_ids)} available accounts. Check logs for details.',
                'type': 'info',
            }
        }


class GmailAccountSwitcherLines(models.TransientModel):
    _name = 'gmail.account.switcher.lines'
    _description = 'Gmail Account Switcher Lines'
    _rec_name = 'account_email'

    switcher_id = fields.Many2one(
        'gmail.account.switcher',
        string='Switcher',
        ondelete='cascade'
    )
    
    account_id = fields.Many2one(
        'gmail.account',
        string='Gmail Account',
        required=True
    )
    
    account_name = fields.Char(
        string='Account Name',
        required=True
    )
    
    account_email = fields.Char(
        string='Email Address',
        required=True
    )
    
    account_status = fields.Selection([
        ('draft', 'Not Connected'),
        ('connecting', 'Connecting'),
        ('connected', 'Connected'),
        ('error', 'Error'),
        ('expired', 'Token Expired'),
        ('suspended', 'Suspended'),
        ('oauth_required', 'OAuth Required'),
    ], string='Status', default='draft')
    
    account_avatar = fields.Binary(
        string='Avatar'
    )
    
    unread_count = fields.Integer(
        string='Unread Messages',
        default=0
    )

    def action_select_account(self):
        """Select this account for switching"""
        self.ensure_one()
        return self.switcher_id.action_switch_account(self.account_id.id)

    def action_sign_out_this_account(self):
        """Sign out this specific account"""
        self.ensure_one()
        return self.switcher_id.action_sign_out_account(self.account_id.id)
