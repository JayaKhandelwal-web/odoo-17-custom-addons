# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError
import base64
import logging

_logger = logging.getLogger(__name__)


class GmailAccountSwitcher(models.TransientModel):
    _name = 'gmail.account.switcher'
    _description = 'Gmail Account Switcher'

    # Current Account Information
    current_account_id = fields.Many2one('gmail.account', string='Current Account')
    current_account_name = fields.Char(string='Current Account Name')
    current_account_email = fields.Char(string='Current Account Email')
    current_account_avatar = fields.Binary(string='Current Account Avatar')
    
    # Dashboard Compatibility Fields
    selected_account_id = fields.Many2one('gmail.account', string='Switch To', 
                                        domain="[('id', 'in', available_account_ids)]")
    available_account_ids = fields.Many2many('gmail.account', string='Available Accounts')
    
    # Other Available Accounts
    other_accounts = fields.One2many('gmail.account.switch.line', 'switcher_id', string='Other Accounts')

    @api.model
    def default_get(self, fields_list):
        """Load current account and other available accounts"""
        res = super().default_get(fields_list)
        
        # Get current connected account for this user
        current_account = self.env['gmail.account'].search([
            ('status', '=', 'connected'),
            ('user_id', '=', self.env.user.id)
        ], limit=1, order='id desc')
        
        if current_account:
            res.update({
                'current_account_id': current_account.id,
                'current_account_name': current_account.name or current_account.email_address.split('@')[0].title(),
                'current_account_email': current_account.email_address,
                'current_account_avatar': self._generate_avatar(current_account.email_address),
            })
        
        # Auto-load other accounts and set compatibility fields
        self._load_other_accounts(res, current_account.id if current_account else None)
        self._set_compatibility_fields(res)
        
        return res

    def _load_other_accounts(self, res, current_account_id):
        """Load other available accounts"""
        domain = [('status', '=', 'connected')]
        
        # Include user's own accounts and shared accounts
        domain = [
            '&', ('status', '=', 'connected'),
            '|',
            ('user_id', '=', self.env.user.id),
            '&', ('access_level', '=', 'shared'), 
            ('shared_user_ids', 'in', [self.env.user.id])
        ]
        
        all_accounts = self.env['gmail.account'].search(domain)
        
        # Filter out current account
        other_accounts = all_accounts.filtered(lambda a: a.id != current_account_id) if current_account_id else all_accounts
        
        line_values = []
        for account in other_accounts:
            line_data = {
                'account_id': account.id,
                'account_name': account.name or account.email_address.split('@')[0].title(),
                'account_email': account.email_address,
                'account_avatar': self._generate_avatar(account.email_address),
                'is_current': False,
            }
            line_values.append((0, 0, line_data))
        
        res['other_accounts'] = line_values
        _logger.info(f"Gmail Switcher: Loaded {len(other_accounts)} other accounts")

    def _set_compatibility_fields(self, res):
        """Set compatibility fields for dashboard integration"""
        # Get all connected accounts for available_account_ids field
        all_accounts = self.env['gmail.account'].search([
            '&', ('status', '=', 'connected'),
            '|',
            ('user_id', '=', self.env.user.id),
            '&', ('access_level', '=', 'shared'), 
            ('shared_user_ids', 'in', [self.env.user.id])
        ])
        
        res['available_account_ids'] = [(6, 0, all_accounts.ids)]

    def _generate_avatar(self, email):
        """Generate simple avatar"""
        try:
            initial = email[0].upper() if email else 'G'
            svg_avatar = f'''<svg width="40" height="40" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="20" fill="#1a73e8"/>
                <text x="20" y="26" font-family="Arial" font-size="14" 
                      fill="white" text-anchor="middle" font-weight="500">{initial}</text>
            </svg>'''
            return base64.b64encode(svg_avatar.encode()).decode()
        except:
            return False

    def load_accounts(self):
        """Reload all accounts"""
        # Get current account
        current_account = self.env['gmail.account'].search([
            ('status', '=', 'connected'),
            ('user_id', '=', self.env.user.id)
        ], limit=1, order='id desc')
        
        if current_account:
            self.current_account_id = current_account.id
            self.current_account_name = current_account.name or current_account.email_address.split('@')[0].title()
            self.current_account_email = current_account.email_address
            self.current_account_avatar = self._generate_avatar(current_account.email_address)
        
        # Clear and reload other accounts
        self.other_accounts.unlink()
        
        domain = [
            '&', ('status', '=', 'connected'),
            '|',
            ('user_id', '=', self.env.user.id),
            '&', ('access_level', '=', 'shared'), 
            ('shared_user_ids', 'in', [self.env.user.id])
        ]
        
        all_accounts = self.env['gmail.account'].search(domain)
        other_accounts = all_accounts.filtered(lambda a: a.id != current_account.id) if current_account else all_accounts
        
        line_values = []
        for account in other_accounts:
            line_data = {
                'switcher_id': self.id,
                'account_id': account.id,
                'account_name': account.name or account.email_address.split('@')[0].title(),
                'account_email': account.email_address,
                'account_avatar': self._generate_avatar(account.email_address),
                'is_current': False,
            }
            line_values.append(line_data)
        
        if line_values:
            self.env['gmail.account.switch.line'].create(line_values)
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Accounts Loaded',
                'message': f'Loaded {len(other_accounts)} available Gmail accounts.',
                'type': 'success',
            }
        }

    def action_switch_account(self):
        """Switch to selected account - Dashboard compatibility method"""
        account_id = self.selected_account_id.id if self.selected_account_id else None
        
        if account_id:
            account = self.env['gmail.account'].browse(account_id)
            if account.exists() and account.status == 'connected':
                # Set in session
                try:
                    from odoo.http import request
                    if request and hasattr(request, 'session'):
                        request.session['gmail_active_account_id'] = account.id
                        _logger.info(f"Switched to Gmail account: {account.email_address}")
                except:
                    pass
                
                # Close modal and show success
                return {
                    'type': 'ir.actions.client',
                    'tag': 'gmail_switch_success',
                    'params': {
                        'account_email': account.email_address,
                    }
                }
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Error',
                'message': 'Please select an account to switch to.',
                'type': 'warning',
            }
        }

    def action_add_account(self):
        """Open add account form"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Add Gmail Account',
            'res_model': 'gmail.account',
            'view_mode': 'form',
            'target': 'current',
            'context': {
                'default_user_id': self.env.user.id,
                'default_access_level': 'private',
            }
        }

    def action_sign_out_current(self):
        """Sign out current account"""
        if self.current_account_id:
            account = self.current_account_id
            try:
                account.action_disconnect_gmail()
                
                # Clear session
                try:
                    from odoo.http import request
                    if request and hasattr(request, 'session'):
                        request.session.pop('gmail_active_account_id', None)
                except:
                    pass
                
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Signed Out',
                        'message': f'Signed out from {account.email_address}',
                        'type': 'info',
                    }
                }
            except Exception as e:
                raise UserError(f'Sign out failed: {str(e)}')
        return False


class GmailAccountSwitchLine(models.TransientModel):
    _name = 'gmail.account.switch.line'
    _description = 'Gmail Account Switch Line'

    switcher_id = fields.Many2one('gmail.account.switcher', ondelete='cascade')
    account_id = fields.Many2one('gmail.account', required=True)
    account_name = fields.Char(required=True)
    account_email = fields.Char(required=True)
    account_avatar = fields.Binary()
    is_current = fields.Boolean(default=False)

    def switch_account(self):
        """Switch to this account - FIXED VERSION"""
        # Skip validation for this action
        self = self.with_context(skip_validation=True)
        
        if self.account_id:
            account = self.account_id
            if account.status == 'connected':
                # Set in session
                try:
                    from odoo.http import request
                    if request and hasattr(request, 'session'):
                        request.session['gmail_active_account_id'] = account.id
                        _logger.info(f"Switched to Gmail account: {account.email_address}")
                except:
                    pass
                
                # Close modal and reload
                return {
                    'type': 'ir.actions.client',
                    'tag': 'reload',
                }
        return False

    def signout_account(self):
        """Sign out this account"""
        if self.account_id:
            account = self.account_id
            try:
                account.action_disconnect_gmail()
                
                # Clear session if current
                try:
                    from odoo.http import request
                    if request and hasattr(request, 'session'):
                        active_account_id = request.session.get('gmail_active_account_id')
                        if active_account_id == account.id:
                            request.session.pop('gmail_active_account_id', None)
                except:
                    pass
                
                # Refresh the view
                self.switcher_id.load_accounts()
                
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Signed Out',
                        'message': f'Signed out from {account.email_address}',
                        'type': 'info',
                    }
                }
            except Exception as e:
                raise UserError(f'Sign out failed: {str(e)}')
        return False
