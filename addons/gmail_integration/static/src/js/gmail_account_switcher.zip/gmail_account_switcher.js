/**
 * Gmail Integration - Account Switcher JavaScript
 * 
 * This module handles Gmail account switching functionality
 * within the Gmail integration module for Odoo 17.
 * 
 * @version 2.2.0 - Enhanced with working account switching
 * @author Gmail Integration Team
 */

(function() {
    'use strict';

    // Scoped within IIFE to prevent global pollution
    console.log('=== Gmail Account Switcher v2.2.0 - Loading ===');

    // Define the Odoo module with proper dependency array for Odoo 17
    odoo.define('gmail_integration.account_switcher', [
        'web.rpc', 
        'web.core', 
        'web.Dialog',
        'web.AbstractField',
        'web.field_registry',
        'web.session'
    ], function(require) {
        'use strict';

        // Import required Odoo modules
        var rpc = require('web.rpc');
        var core = require('web.core');
        var Dialog = require('web.Dialog');
        var session = require('web.session');
        
        // Simple fallback if modules don't load properly
        if (typeof rpc === 'undefined') {
            console.warn('RPC module not available, using fallback');
            rpc = {
                query: function(params) {
                    return $.ajax({
                        url: '/web/dataset/call_kw',
                        type: 'POST',
                        dataType: 'json',
                        contentType: 'application/json',
                        data: JSON.stringify({
                            jsonrpc: '2.0',
                            method: 'call',
                            params: {
                                model: params.model,
                                method: params.method,
                                args: params.args || [],
                                kwargs: params.kwargs || {}
                            }
                        })
                    }).then(function(result) {
                        if (result.error) {
                            throw new Error(result.error.message || result.error.data.message);
                        }
                        return result.result;
                    });
                }
            };
        }
        
        console.log('=== Gmail Account Switcher - Module Loaded ===');

        /**
         * Configuration object for the switcher
         */
        var Config = {
            selectors: {
                switcherCard: '.gmail-other-item',
                signOutBtn: '.gmail-signout-btn',
                modal: '.o_dialog, .modal',
                closeBtn: '.modal .btn[data-dismiss="modal"], .o_dialog .btn[special="cancel"]',
                form: 'form.gmail-account-switcher-modal'
            },
            events: {
                cardClick: 'click.gmailAccountSwitcher',
                modalShown: 'shown.bs.modal'
            },
            timeouts: {
                modalClose: 800,
                pageReload: 1000,
                debounce: 300
            },
            animations: {
                duration: 300
            }
        };

        /**
         * Utility functions scoped within the module
         */
        var Utils = {
            /**
             * Make RPC call to Odoo backend
             * @param {string} model - Odoo model name
             * @param {string} method - Method name to call
             * @param {Array} args - Arguments array
             * @param {Object} kwargs - Keyword arguments
             * @returns {Promise} RPC promise
             */
            callOdooMethod: function(model, method, args, kwargs) {
                return rpc.query({
                    model: model,
                    method: method,
                    args: args || [],
                    kwargs: kwargs || {}
                });
            },

            /**
             * Extract account ID from element with multiple fallback methods
             * @param {jQuery} $element - jQuery element
             * @returns {number|null} Account ID or null
             */
            getAccountId: function($element) {
                // Try multiple ways to get account ID
                var accountId = null;
                
                // Method 1: Direct data attribute
                accountId = $element.attr('data-account-id') || $element.data('account-id');
                
                // Method 2: Find in kanban record data
                if (!accountId) {
                    var $kanbanRecord = $element.closest('.o_kanban_record');
                    if ($kanbanRecord.length) {
                        accountId = $kanbanRecord.attr('data-id') || $kanbanRecord.data('id');
                    }
                }
                
                // Method 3: Look for hidden debug field
                if (!accountId) {
                    var debugId = $element.find('.debug-account-id').text().trim();
                    if (debugId) accountId = debugId;
                }
                
                // Method 4: Look for hidden input field
                if (!accountId) {
                    var hiddenField = $element.find('.account-id-field').val();
                    if (hiddenField) accountId = hiddenField;
                }
                
                var parsed = parseInt(accountId, 10);
                console.log('Account ID extraction - Raw:', accountId, 'Parsed:', parsed);
                
                return isNaN(parsed) ? null : parsed;
            },

            /**
             * Apply visual feedback to card
             * @param {jQuery} $card - Card element
             * @param {string} state - 'loading', 'success', 'error', or 'normal'
             */
            setCardState: function($card, state) {
                // Remove all state classes first
                $card.removeClass('gmail-card-loading gmail-card-success gmail-card-error');
                
                switch(state) {
                    case 'loading':
                        $card.addClass('gmail-card-loading').css({
                            'opacity': '0.8',
                            'border-color': '#4285f4',
                            'background': 'linear-gradient(135deg, #e8f0fe 0%, #f0f4ff 100%)',
                            'transform': 'scale(0.98)',
                            'pointer-events': 'none'
                        });
                        
                        // Add loading spinner
                        if (!$card.find('.gmail-loading-spinner').length) {
                            $card.append('<div class="gmail-loading-spinner" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 20;"><i class="fa fa-spinner fa-spin" style="color: #4285f4; font-size: 16px;"></i></div>');
                        }
                        break;
                        
                    case 'success':
                        $card.addClass('gmail-card-success').css({
                            'opacity': '1',
                            'border-color': '#34a853',
                            'background': 'linear-gradient(135deg, #e8f5e8 0%, #f0f8f0 100%)',
                            'transform': 'scale(1.02)'
                        });
                        break;
                        
                    case 'error':
                        $card.addClass('gmail-card-error').css({
                            'opacity': '1',
                            'border-color': '#ea4335',
                            'background': 'linear-gradient(135deg, #fce8e6 0%, #fef0ef 100%)',
                            'transform': 'scale(1)'
                        });
                        break;
                        
                    default: // normal
                        $card.css({
                            'opacity': '1',
                            'border-color': '#dee2e6',
                            'background': 'white',
                            'transform': 'scale(1)',
                            'pointer-events': 'auto'
                        });
                        $card.find('.gmail-loading-spinner').remove();
                        break;
                }
            },

            /**
             * Show enhanced user notification
             * @param {string} message - Message to show
             * @param {string} type - 'success', 'error', 'warning', or 'info'
             * @param {number} duration - Duration in milliseconds
             */
            showNotification: function(message, type, duration) {
                type = type || 'info';
                duration = duration || (type === 'error' ? 5000 : 3000);
                
                console.log('[Gmail Switcher] ' + type.toUpperCase() + ': ' + message);
                
                // Enhanced notification styling
                var colors = {
                    success: { bg: '#34a853', icon: 'fa-check-circle' },
                    error: { bg: '#ea4335', icon: 'fa-exclamation-circle' },
                    warning: { bg: '#fbbc04', icon: 'fa-exclamation-triangle' },
                    info: { bg: '#4285f4', icon: 'fa-info-circle' }
                };
                
                var config = colors[type] || colors.info;
                
                var $notification = $('<div>')
                    .css({
                        'position': 'fixed',
                        'top': '20px',
                        'right': '20px',
                        'background': config.bg,
                        'color': 'white',
                        'padding': '12px 20px',
                        'border-radius': '8px',
                        'z-index': '99999',
                        'font-size': '14px',
                        'font-weight': '500',
                        'box-shadow': '0 8px 32px rgba(0, 0, 0, 0.2)',
                        'display': 'flex',
                        'align-items': 'center',
                        'gap': '8px',
                        'max-width': '300px',
                        'transform': 'translateX(100%)',
                        'transition': 'transform 0.3s ease'
                    })
                    .html('<i class="fa ' + config.icon + '"></i>' + message)
                    .appendTo('body');
                
                // Slide in animation
                setTimeout(function() {
                    $notification.css('transform', 'translateX(0)');
                }, 10);
                
                // Auto hide
                setTimeout(function() {
                    $notification.css('transform', 'translateX(100%)');
                    setTimeout(function() {
                        $notification.remove();
                    }, 300);
                }, duration);
            },

            /**
             * Debounce function to prevent rapid clicks
             * @param {Function} func - Function to debounce
             * @param {number} wait - Wait time in milliseconds
             * @returns {Function} Debounced function
             */
            debounce: function(func, wait) {
                var timeout;
                return function executedFunction() {
                    var context = this;
                    var args = arguments;
                    var later = function() {
                        timeout = null;
                        func.apply(context, args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }
        };

        /**
         * Main account switcher functionality - ENHANCED WITH WORKING SWITCHING
         */
        var AccountSwitcher = {
            // Track if switch is in progress
            switchInProgress: false,

            /**
             * Switch to specified Gmail account - ENHANCED VERSION THAT WORKS
             * @param {number} accountId - Target account ID
             * @param {jQuery} $card - Card element (optional)
             * @returns {Promise} Switch operation promise
             */
            switchAccount: function(accountId, $card) {
                console.log('=== Switching to Gmail Account ID:', accountId, '===');
                
                // Prevent multiple simultaneous switches
                if (AccountSwitcher.switchInProgress) {
                    console.log('Switch already in progress, ignoring...');
                    return Promise.reject('Switch already in progress');
                }
                
                AccountSwitcher.switchInProgress = true;
                
                // Apply loading state to card
                if ($card) {
                    Utils.setCardState($card, 'loading');
                }
                
                // Use the enhanced dashboard method
                return Utils.callOdooMethod('gmail.dashboard', 'force_dashboard_refresh_with_account', [accountId])
                    .then(function(result) {
                        console.log('Switch result:', result);
                        
                        if (result && result.success) {
                            console.log('Account switch successful!');
                            
                            // Apply success state
                            if ($card) {
                                Utils.setCardState($card, 'success');
                            }
                            
                            // Show success message
                            var accountInfo = result.account_email || result.account_name || 'selected account';
                            Utils.showNotification(
                                'Successfully switched to ' + accountInfo, 
                                'success', 
                                2000
                            );
                            
                            // Execute the action returned from server if available
                            if (result.action) {
                                console.log('Executing server action...');
                                setTimeout(function() {
                                    AccountSwitcher._executeAction(result.action);
                                }, Config.timeouts.modalClose);
                            } else {
                                // Fallback: close modal and reload
                                setTimeout(function() {
                                    AccountSwitcher._closeModalAndReload();
                                }, Config.timeouts.modalClose);
                            }
                            
                            return result;
                        } else {
                            var errorMsg = 'Failed to switch account';
                            if (result && result.error) {
                                errorMsg += ': ' + result.error;
                            }
                            throw new Error(errorMsg);
                        }
                    })
                    .catch(function(error) {
                        console.error('Account switch error:', error);
                        
                        // Apply error state to card
                        if ($card) {
                            Utils.setCardState($card, 'error');
                            setTimeout(function() {
                                Utils.setCardState($card, 'normal');
                            }, 2000);
                        }
                        
                        var errorMessage = 'Failed to switch account';
                        if (typeof error === 'string') {
                            errorMessage = error;
                        } else if (error && error.message) {
                            errorMessage = error.message;
                        } else if (error && error.data && error.data.message) {
                            errorMessage = error.data.message;
                        }
                        
                        Utils.showNotification(errorMessage, 'error');
                        throw error;
                    })
                    .finally(function() {
                        AccountSwitcher.switchInProgress = false;
                    });
            },

            /**
             * Execute Odoo action (NEW)
             * @param {Object} action - Odoo action to execute
             */
            _executeAction: function(action) {
                try {
                    // Close modal first
                    AccountSwitcher._closeModal();
                    
                    // Try to use Odoo's action manager if available
                    if (window.odoo && window.odoo.web && window.odoo.web.action_manager) {
                        console.log('Using Odoo action manager');
                        window.odoo.web.action_manager.doAction(action);
                    } else {
                        // Fallback: redirect to dashboard with context
                        var url = '/web#action=gmail_integration.action_gmail_dashboard';
                        if (action.context && action.context.force_active_account_id) {
                            url += '&force_active_account_id=' + action.context.force_active_account_id;
                        }
                        console.log('Redirecting to:', url);
                        window.location.href = url;
                    }
                } catch (e) {
                    console.error('Error executing action:', e);
                    AccountSwitcher._closeModalAndReload();
                }
            },

            /**
             * Close modal only (NEW)
             */
            _closeModal: function() {
                try {
                    var $closeBtn = $(Config.selectors.closeBtn);
                    if ($closeBtn.length > 0) {
                        $closeBtn.first().click();
                    } else {
                        $('.o_dialog .o_dialog_close, .modal .close').first().click();
                    }
                } catch (e) {
                    console.error('Error closing modal:', e);
                }
            },

            /**
             * Close modal and reload page
             */
            _closeModalAndReload: function() {
                try {
                    AccountSwitcher._closeModal();
                    
                    // Reload page after a delay
                    setTimeout(function() {
                        console.log('Reloading page to show switched account...');
                        window.location.reload();
                    }, Config.timeouts.pageReload);
                    
                } catch (e) {
                    console.error('Error closing modal:', e);
                    setTimeout(function() {
                        window.location.reload();
                    }, Config.timeouts.pageReload);
                }
            },

            /**
             * Handle card click events with enhanced debugging
             */
            handleCardClick: Utils.debounce(function(event) {
                console.log('=== Gmail Account Card Clicked ===');
                
                // Prevent default behavior
                event.preventDefault();
                event.stopPropagation();
                
                // Ignore if switch is in progress
                if (AccountSwitcher.switchInProgress) {
                    console.log('Switch in progress, ignoring click');
                    return;
                }
                
                // Ignore sign out button clicks
                if ($(event.target).closest(Config.selectors.signOutBtn).length > 0) {
                    console.log('Sign out button clicked - ignoring card click');
                    return;
                }
                
                var $card = $(event.currentTarget);
                var accountId = Utils.getAccountId($card);
                
                console.log('Final extracted account ID:', accountId);
                
                if (!accountId) {
                    console.error('No valid account ID found on card');
                    Utils.showNotification('Could not identify account. Please try again.', 'error');
                    return;
                }
                
                // Perform switch
                AccountSwitcher.switchAccount(accountId, $card);
                
            }, Config.timeouts.debounce),

            /**
             * Initialize event handlers with multiple binding strategies
             */
            initializeHandlers: function() {
                console.log('=== Initializing Gmail Account Switcher Handlers ===');
                
                // Remove any existing handlers to prevent duplicates
                $(document).off(Config.events.cardClick);
                
                // Primary event binding
                $(document).on(Config.events.cardClick, Config.selectors.switcherCard, AccountSwitcher.handleCardClick);
                
                // Fallback bindings
                $(document).on(Config.events.cardClick, '.gmail-other-section .o_kanban_record', AccountSwitcher.handleCardClick);
                $(document).on(Config.events.cardClick, '.gmail-account-item:not(.gmail-current-item)', AccountSwitcher.handleCardClick);
                
                console.log('=== Gmail Account Switcher Handlers Registered ===');
            },

            /**
             * Debug function to check for available cards and their data
             */
            debugCheckCards: function() {
                console.log('=== Gmail Account Switcher Debug Check ===');
                
                var cards = $(Config.selectors.switcherCard);
                console.log('Found ' + cards.length + ' cards with selector:', Config.selectors.switcherCard);
                
                if (cards.length > 0) {
                    cards.each(function(index, card) {
                        var $card = $(card);
                        var accountId = Utils.getAccountId($card);
                        var accountName = $card.find('.gmail-name').text().trim();
                        var accountEmail = $card.find('.gmail-email').text().trim();
                        
                        console.log('Card ' + (index + 1) + ': ID=' + accountId + ', Name=' + accountName + ', Email=' + accountEmail);
                    });
                } else {
                    console.log('No Gmail account cards found in DOM');
                }
            },

            /**
             * Enhanced initialization
             */
            initialize: function() {
                console.log('=== Starting Gmail Account Switcher Initialization ===');
                
                try {
                    AccountSwitcher.initializeHandlers();
                    AccountSwitcher.debugCheckCards();
                    
                    console.log('=== Gmail Account Switcher Initialization Complete ===');
                } catch (error) {
                    console.error('=== Gmail Account Switcher Initialization Failed ===', error);
                }
            },

            /**
             * Cleanup function
             */
            cleanup: function() {
                console.log('=== Cleaning up Gmail Account Switcher ===');
                $(document).off(Config.events.cardClick);
                AccountSwitcher.switchInProgress = false;
            }
        };

        /**
         * Event handlers for different initialization scenarios
         */
        var EventHandlers = {
            onDocumentReady: function() {
                console.log('=== Document Ready - Starting Gmail Account Switcher ===');
                AccountSwitcher.initialize();
            },

            onModalShown: function() {
                console.log('=== Modal/Dialog Opened - Re-initializing Gmail Switcher ===');
                setTimeout(function() {
                    AccountSwitcher.initializeHandlers();
                    AccountSwitcher.debugCheckCards();
                }, 300);
            },

            onWebClientReady: function() {
                console.log('=== Odoo Web Client Ready - Initializing Gmail Switcher ===');
                setTimeout(function() {
                    AccountSwitcher.initialize();
                }, 500);
            }
        };

        // Event bindings
        $(document).ready(EventHandlers.onDocumentReady);
        $(document).on(Config.events.modalShown, Config.selectors.modal, EventHandlers.onModalShown);
        
        if (core.bus) {
            core.bus.on('web_client_ready', null, EventHandlers.onWebClientReady);
        }

        // Public API
        console.log('=== Gmail Account Switcher Module Definition Complete ===');
        
        return {
            switchAccount: AccountSwitcher.switchAccount,
            initialize: AccountSwitcher.initialize,
            debugCheckCards: AccountSwitcher.debugCheckCards,
            cleanup: AccountSwitcher.cleanup,
            config: Config,
            version: '2.2.0'
        };
    });

    // Enhanced standalone version that works with your RPC system
    window.GmailAccountSwitcherStandalone = {
        /**
         * Enhanced account switching function that works with direct RPC and action execution
         * @param {number} accountId - Account ID to switch to
         */
        switchAccount: function(accountId) {
            console.log('=== Standalone Switch Account ===', accountId);
            
            if (!accountId) {
                alert('No account ID provided');
                return;
            }
            
            // Show loading state
            $('.gmail-other-item').addClass('clicked');
            
            // Use direct RPC with enhanced error handling
            if (window.rpc && window.rpc.query) {
                console.log('Using direct RPC');
                window.rpc.query({
                    model: 'gmail.dashboard',
                    method: 'force_dashboard_refresh_with_account',
                    args: [accountId]
                }).then(function(result) {
                    console.log('✅ RPC Success:', result);
                    
                    if (result && result.success) {
                        console.log('✅ Account switch successful!');
                        
                        // Close modal
                        $('.modal .btn[special="cancel"]').click();
                        
                        // Execute action if provided, otherwise redirect
                        if (result.action) {
                            console.log('✅ Executing server action...');
                            setTimeout(function() {
                                try {
                                    if (window.odoo && window.odoo.web && window.odoo.web.action_manager) {
                                        window.odoo.web.action_manager.doAction(result.action);
                                    } else {
                                        window.location.href = '/web#action=gmail_integration.action_gmail_dashboard&force_active_account_id=' + accountId;
                                    }
                                } catch (e) {
                                    console.error('Action execution failed:', e);
                                    window.location.href = '/web#action=gmail_integration.action_gmail_dashboard';
                                }
                            }, 500);
                        } else {
                            setTimeout(function() {
                                window.location.href = '/web#action=gmail_integration.action_gmail_dashboard';
                            }, 500);
                        }
                    } else {
                        console.error('❌ Switch failed:', result);
                        alert('Failed to switch account: ' + (result ? result.error : 'Unknown error'));
                        $('.gmail-other-item').removeClass('clicked');
                    }
                }).catch(function(error) {
                    console.error('❌ RPC Error:', error);
                    
                    // Fallback to URL parameter approach
                    console.log('RPC failed, using URL parameter fallback');
                    $('.modal .btn[special="cancel"]').click();
                    setTimeout(function() {
                        window.location.href = '/web#action=gmail_integration.action_gmail_dashboard&force_active_account_id=' + accountId;
                    }, 500);
                });
            } else {
                // Direct URL parameter approach
                console.log('Using URL parameter approach');
                $('.modal .btn[special="cancel"]').click();
                setTimeout(function() {
                    window.location.href = '/web#action=gmail_integration.action_gmail_dashboard&force_active_account_id=' + accountId;
                }, 500);
            }
        },

        /**
         * Test function to check available accounts
         */
        testAccounts: function() {
            console.log('=== Testing Account Detection ===');
            var accounts = [];
            
            $('.gmail-other-item').each(function(index) {
                var $item = $(this);
                var accountData = {
                    index: index,
                    element: this,
                    dataAccountId: $item.attr('data-account-id'),
                    dataId: $item.attr('data-id'),
                    debugId: $item.find('.debug-account-id').text().trim(),
                    hiddenField: $item.find('.account-id-field').val(),
                    name: $item.find('.gmail-name').text().trim(),
                    email: $item.find('.gmail-email').text().trim()
                };
                
                console.log('Account ' + (index + 1) + ':', accountData);
                accounts.push(accountData);
            });
            
            return accounts;
        },

        /**
         * Initialize standalone event handlers
         */
        init: function() {
            console.log('=== Initializing Standalone Gmail Switcher ===');
            
            // Remove existing handlers
            $(document).off('click.gmailStandalone');
            
            // Add click handlers for account items
            $(document).on('click.gmailStandalone', '.gmail-other-item', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                // Don't trigger on sign out button
                if ($(e.target).closest('.gmail-signout-btn').length > 0) {
                    console.log('Sign out button clicked, ignoring');
                    return;
                }
                
                console.log('=== Standalone Click Handler ===');
                
                var $item = $(this);
                var accountId = $item.attr('data-account-id') || 
                               $item.data('account-id') ||
                               $item.find('.debug-account-id').text().trim() ||
                               $item.find('.account-id-field').val();
                
                console.log('Extracted account ID:', accountId);
                
                if (accountId && !isNaN(parseInt(accountId))) {
                    $item.addClass('clicked');
                    GmailAccountSwitcherStandalone.switchAccount(parseInt(accountId));
                } else {
                    console.error('Could not extract valid account ID from element');
                    alert('Could not identify account to switch to. Check console for details.');
                }
            });
            
            console.log('=== Standalone handlers attached ===');
            
            // Run test to see what's available
            setTimeout(function() {
                GmailAccountSwitcherStandalone.testAccounts();
            }, 500);
        }
    };

    console.log('=== Gmail Account Switcher v2.2.0 - Module Definition Complete ===');

})();
